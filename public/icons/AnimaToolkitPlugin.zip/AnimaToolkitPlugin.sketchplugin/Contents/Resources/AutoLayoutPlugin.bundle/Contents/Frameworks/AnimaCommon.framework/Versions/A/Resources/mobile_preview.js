window.addEventListener('DOMContentLoaded', function () {
    for (var ls = document.links, numLinks = ls.length, i=0; i<numLinks; i++){
        var currLink = ls[i].href;
        if (currLink.startsWith("anima://")) {
            ls[i].href = currLink.replace("anima://", "/");
            console.log(ls[i].href);
        } else if (currLink.startsWith("http")) {
            ls[i].href = "/" + currLink;
            console.log(ls[i].href);
        }
    }
});

